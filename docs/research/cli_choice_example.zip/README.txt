사용법
- argparse, typer, textual 폴더 각 폴더별로 터미널에서 python -m pip install -r requirements.txt 실행하셔서 라이브러리 다운
- argparse, typer은 python main.py -h 입력해서 명령어 목록 확인
- textual은 python main.py로 TUI화면 실행

세 경우 비교하기 위해 뼈대만 있는 코드들을 각각 만들어놓은 것이고 임시로 명령어 입력하면
argparse는 마크다운 파일을 그냥 파이썬 기본 print로 출력하고 typer는 rich를 적용해서 출력합니다.