import typer
from pathlib import Path

import osscalendar
import checklist
import templates

DOCS_DIR = Path("docs")

app = typer.Typer(
    name="oss",
    help="foss 8 CLI(Typer)",
    no_args_is_help=True,
)


@app.command()
def init():
    """Initialize the document project."""
    DOCS_DIR.mkdir(exist_ok=True)
    print("Document project initialized.")


# 각 기능을 sub-Typer로 등록
app.add_typer(
    osscalendar.app,
    name="calendar",
    help="calendar parser",
)

app.add_typer(
    checklist.app,
    name="checklist",
    help="checklist parser",
)

app.add_typer(
    templates.app,
    name="templates",
    help="templates parser",
)


if __name__ == "__main__":
    app()