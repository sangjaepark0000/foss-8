from pathlib import Path

import typer
from rich.console import Console
from rich.markdown import Markdown


DOCS_DIR = Path("docs")

app = typer.Typer(
    invoke_without_command=True,
    no_args_is_help=False,
)

console = Console()


@app.callback()
def calendar():
    """Show roadmap."""
    file_path = DOCS_DIR / "03-roadmap.md"

    if not file_path.exists():
        console.print(f"[red]File not found:[/red] {file_path}")
        return

    content = file_path.read_text(encoding="utf-8")
    console.print(Markdown(content))