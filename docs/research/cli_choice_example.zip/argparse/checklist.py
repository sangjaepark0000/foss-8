import argparse
from pathlib import Path

DOCS_DIR = Path("docs")


def show_checklist(args):
    file_path = DOCS_DIR / "appendix-a-checklist.md"

    if not file_path.exists():
        print(f"File not found: {file_path}")
        return

    print(file_path.read_text(encoding="utf-8"))

def setup_parser(subparsers):
    parser = subparsers.add_parser("checklist", help="checklist parser")
    parser.set_defaults(func=show_checklist)