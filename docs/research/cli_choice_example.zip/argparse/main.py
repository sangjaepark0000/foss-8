import argparse
from pathlib import Path
import osscalendar
import checklist
import templates

DOCS_DIR = Path("docs")

def run_init(args):
    DOCS_DIR.mkdir(exist_ok=True)

def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="oss",
        description="foss 8 CLI(argparse)"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    init_parser = subparsers.add_parser("init", help="Initialize the document project.")
    init_parser.set_defaults(func=run_init)
    osscalendar.setup_parser(subparsers)
    checklist.setup_parser(subparsers)
    templates.setup_parser(subparsers)

    return parser



def main():
    parser = make_parser()
    args = parser.parse_args()
    if hasattr(args,"func"):
        args.func(args)

if __name__ == "__main__":
    main()