import argparse
from pathlib import Path

DOCS_DIR = Path("docs")


def run_calendar(args):
    file_path = DOCS_DIR / "03-roadmap.md"

    if not file_path.exists():
        print(f"File not found: {file_path}")
        return

    print(file_path.read_text(encoding="utf-8"))


def setup_parser(subparsers):
    parser = subparsers.add_parser("calendar", help="calendar parser")
    parser.set_defaults(func=run_calendar)