from pathlib import Path


DOCS_DIR = Path("docs")
MARKDOWN_FILE = "appendix-c-templates.md"


def get_templates_markdown() -> str:
    file_path = DOCS_DIR / MARKDOWN_FILE

    if not file_path.exists():
        return f"# Error\n\n파일을 찾을 수 없습니다.\n\n`{file_path}`"

    return file_path.read_text(encoding="utf-8")