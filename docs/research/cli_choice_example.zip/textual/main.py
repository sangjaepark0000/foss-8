from pathlib import Path

from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Footer, Header, MarkdownViewer

import osscalendar
import checklist
import templates


DOCS_DIR = Path("docs")


class OssApp(App):
    TITLE = "OSS"
    SUB_TITLE = "foss 8 TUI"

    CSS = """
    Screen {
        layout: vertical;
    }

    #menu {
        height: 3;
        padding: 0 1;
    }

    #menu Button {
        width: 1fr;
        margin: 0 1;
    }

    #viewer {
        height: 1fr;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
    ]

    def compose(self) -> ComposeResult:
        yield Header()

        with Horizontal(id="menu"):
            yield Button("Calendar", id="calendar")
            yield Button("Checklist", id="checklist")
            yield Button("Templates", id="templates")

        yield MarkdownViewer(
            "# OSS\n\n문서를 선택하세요.",
            show_table_of_contents=True,
            id="viewer",
        )

        yield Footer()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        viewer = self.query_one("#viewer", MarkdownViewer)

        if event.button.id == "calendar":
            content = osscalendar.get_calendar_markdown()

        elif event.button.id == "checklist":
            content = checklist.get_checklist_markdown()

        elif event.button.id == "templates":
            content = templates.get_templates_markdown()

        else:
            return

        viewer.document.update(content)


if __name__ == "__main__":
    OssApp().run()